<?php
// backend/api/config.example.php
// Copy this file to `config.php` and fill in with real credentials.

return [
    'host' => 'localhost',
    'port' => 3306,
    'database' => 'genesis_portal',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
];
